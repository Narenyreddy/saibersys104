var fs  = require("fs");

// this is assumed as non-blocking, but it is blocking
myReadFile("log2.js","utf8", function(error,data){
    console.log(data);
});


console.log("other code: " + (4+9));

function myReadFile(fileName,encoding,callback)
{
    //blocking
    var data =  fs.readFileSync(fileName,encoding);
    callback(encoding,data);
}