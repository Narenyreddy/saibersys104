//this function is invoked when document.ready event is raised, which happens when the page is loded in the browser, it is autoinvoked function
$(function(){
    $.get('quotes.csv',function(data){
       // var html = htmlQuotes(data);
        //$('#result').html(html);
        
        $('#result').html(local);
    
    });
})


/*function htmlQuotes(quotes){
    return quotes.split(/\n/)
    .map(function (lines) {
        var columns = lines.split(/,/);
        var company = columns[0].replace(/\"/g,"")
        var price = columns[2]
            return `${company} : ${price}<br/>`;
    });
}*/

