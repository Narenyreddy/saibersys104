function htmlQuotes(quotes){
    return quotes.split(/\n/)
    .map(function (lines) {
        var columns = lines.split(/,/);
        var company = columns[0].replace(/\"/g,"")
        var price = columns[2]
            return `${company} : ${price}<br/>`;
    });
}

var local="hai";

module.exports.local = local;

//module.exports = htmlQuotes;
