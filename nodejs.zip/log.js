var fs = require("fs");


//non-blocking
// filename, 8 bit unicode char set, callback
fs.readFile("log.js","utf8", function(error,data){
   console.log(data); 
    console.log(error);
});

console.log(2+3);