var fs  = require("fs");
//var htmlQuotes = require("./parser.js");

var local = require("./parser.js");

console.log(local);
fs.readFile("quotes.csv","utf8", (error,data) => {
//            var html = htmlQuotes(data);
//        console.log(html);
            });



