var fs = require("fs");

// filename, 8 bit unicode char set, callback
//fs.readFile("log1.js","utf8", function(error,data){
//   console.log(data); 
//    console.log(error);
//});

//blocking operation
 var data = fs.readFileSync("log1.js","utf8");

console.log(data);
console.log(2+3);